import { boxes, boxActivities, users, type Box, type InsertBox, type BoxActivity, type InsertBoxActivity, type User, type InsertUser, BoxStatus } from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, or, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Box methods
  createBox(box: InsertBox): Promise<Box>;
  getBox(id: number): Promise<Box | undefined>;
  getBoxByBoxId(boxId: string): Promise<Box | undefined>;
  getAllBoxes(): Promise<Box[]>;
  updateBox(id: number, updates: Partial<Box>): Promise<Box>;
  getBoxesByStatus(status: string): Promise<Box[]>;
  searchBoxes(query: string): Promise<Box[]>;

  // Box activity methods
  createBoxActivity(activity: InsertBoxActivity): Promise<BoxActivity>;
  getBoxActivities(boxId: string): Promise<BoxActivity[]>;
  getRecentActivities(limit?: number): Promise<BoxActivity[]>;

  // Analytics methods
  getBoxStatusCounts(): Promise<Record<string, number>>;
  getBoxMetrics(): Promise<{
    totalBoxes: number;
    inTransit: number;
    delivered: number;
    utilizationRate: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private boxes: Map<number, Box>;
  private boxActivities: Map<number, BoxActivity>;
  private currentUserId: number;
  private currentBoxId: number;
  private currentActivityId: number;

  constructor() {
    this.users = new Map();
    this.boxes = new Map();
    this.boxActivities = new Map();
    this.currentUserId = 1;
    this.currentBoxId = 1;
    this.currentActivityId = 1;

    // Initialize with some demo data
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Create sample boxes
    const sampleBoxes = [
      {
        boxId: 'SB-001847',
        type: 'Standard - Medium (25L)',
        status: BoxStatus.DELIVERED,
        currentLocation: 'Warehouse A, Dock 2',
        cycles: 23,
      },
      {
        boxId: 'SB-001523',
        type: 'Standard - Large (50L)',
        status: BoxStatus.IN_TRANSIT,
        currentLocation: 'Highway Route 95',
        cycles: 47,
      },
      {
        boxId: 'SB-002103',
        type: 'Standard - Small (10L)',
        status: BoxStatus.NEW,
        currentLocation: 'Production Facility',
        cycles: 0,
      },
      {
        boxId: 'SB-001298',
        type: 'Refrigerated - Medium (25L)',
        status: BoxStatus.MAINTENANCE,
        currentLocation: 'Repair Center B',
        cycles: 89,
      },
      {
        boxId: 'SB-001756',
        type: 'Standard - Medium (25L)',
        status: BoxStatus.RETURNED,
        currentLocation: 'Central Hub',
        cycles: 34,
      },
    ];

    sampleBoxes.forEach((box) => {
      const id = this.currentBoxId++;
      const newBox: Box = {
        id,
        ...box,
        lastUpdated: new Date(),
      };
      this.boxes.set(id, newBox);

      // Create activity for each box
      const activityId = this.currentActivityId++;
      const activity: BoxActivity = {
        id: activityId,
        boxId: box.boxId,
        action: `Box ${box.status === BoxStatus.NEW ? 'registered as new' : 
                      box.status === BoxStatus.IN_TRANSIT ? 'in transit' :
                      box.status === BoxStatus.DELIVERED ? 'delivered' :
                      box.status === BoxStatus.RETURNED ? 'returned' :
                      'requires maintenance'}`,
        location: box.currentLocation,
        timestamp: new Date(Date.now() - Math.random() * 7200000), // Random time in last 2 hours
      };
      this.boxActivities.set(activityId, activity);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createBox(insertBox: InsertBox): Promise<Box> {
    const id = this.currentBoxId++;
    const generatedBoxId = `SB-${String(id).padStart(6, '0')}`;
    const box: Box = {
      id,
      boxId: generatedBoxId,
      type: insertBox.type,
      status: insertBox.status,
      currentLocation: insertBox.currentLocation,
      cycles: insertBox.cycles || 0,
      lastUpdated: new Date(),
    };
    this.boxes.set(id, box);

    // Create initial activity
    await this.createBoxActivity({
      boxId: generatedBoxId,
      action: 'Box registered as new',
      location: insertBox.currentLocation,
    });

    return box;
  }

  async getBox(id: number): Promise<Box | undefined> {
    return this.boxes.get(id);
  }

  async getBoxByBoxId(boxId: string): Promise<Box | undefined> {
    return Array.from(this.boxes.values()).find(box => box.boxId === boxId);
  }

  async getAllBoxes(): Promise<Box[]> {
    return Array.from(this.boxes.values()).sort((a, b) => 
      new Date(b.lastUpdated!).getTime() - new Date(a.lastUpdated!).getTime()
    );
  }

  async updateBox(id: number, updates: Partial<Box>): Promise<Box> {
    const box = this.boxes.get(id);
    if (!box) {
      throw new Error('Box not found');
    }

    const updatedBox: Box = {
      ...box,
      ...updates,
      lastUpdated: new Date(),
    };
    this.boxes.set(id, updatedBox);

    // Create activity if status changed
    if (updates.status) {
      await this.createBoxActivity({
        boxId: box.boxId,
        action: `Status updated to ${updates.status}`,
        location: updates.currentLocation || box.currentLocation,
      });
    }

    return updatedBox;
  }

  async getBoxesByStatus(status: string): Promise<Box[]> {
    return Array.from(this.boxes.values()).filter(box => box.status === status);
  }

  async searchBoxes(query: string): Promise<Box[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.boxes.values()).filter(box =>
      box.boxId.toLowerCase().includes(lowercaseQuery) ||
      box.status.toLowerCase().includes(lowercaseQuery) ||
      box.currentLocation.toLowerCase().includes(lowercaseQuery) ||
      box.type.toLowerCase().includes(lowercaseQuery)
    );
  }

  async createBoxActivity(insertActivity: InsertBoxActivity): Promise<BoxActivity> {
    const id = this.currentActivityId++;
    const activity: BoxActivity = {
      id,
      boxId: insertActivity.boxId,
      action: insertActivity.action,
      location: insertActivity.location || null,
      timestamp: new Date(),
    };
    this.boxActivities.set(id, activity);
    return activity;
  }

  async getBoxActivities(boxId: string): Promise<BoxActivity[]> {
    return Array.from(this.boxActivities.values())
      .filter(activity => activity.boxId === boxId)
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime());
  }

  async getRecentActivities(limit: number = 10): Promise<BoxActivity[]> {
    return Array.from(this.boxActivities.values())
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime())
      .slice(0, limit);
  }

  async getBoxStatusCounts(): Promise<Record<string, number>> {
    const counts: Record<string, number> = {};
    Array.from(this.boxes.values()).forEach(box => {
      counts[box.status] = (counts[box.status] || 0) + 1;
    });
    return counts;
  }

  async getBoxMetrics(): Promise<{
    totalBoxes: number;
    inTransit: number;
    delivered: number;
    utilizationRate: number;
  }> {
    const allBoxes = Array.from(this.boxes.values());
    const totalBoxes = allBoxes.length;
    const inTransit = allBoxes.filter(box => box.status === BoxStatus.IN_TRANSIT).length;
    const delivered = allBoxes.filter(box => box.status === BoxStatus.DELIVERED).length;
    
    // Calculate utilization rate as percentage of boxes that are actively used (not new or in maintenance)
    const activeBoxes = allBoxes.filter(box => 
      box.status !== BoxStatus.NEW && box.status !== BoxStatus.MAINTENANCE
    ).length;
    const utilizationRate = totalBoxes > 0 ? Math.round((activeBoxes / totalBoxes) * 100) : 0;

    return {
      totalBoxes,
      inTransit,
      delivered,
      utilizationRate,
    };
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createBox(insertBox: InsertBox): Promise<Box> {
    const [box] = await db
      .insert(boxes)
      .values({
        ...insertBox,
        cycles: insertBox.cycles || 0,
      })
      .returning();

    // Create initial activity
    await this.createBoxActivity({
      boxId: box.boxId,
      action: 'Box registered as new',
      location: insertBox.currentLocation,
    });

    return box;
  }

  async getBox(id: number): Promise<Box | undefined> {
    const [box] = await db.select().from(boxes).where(eq(boxes.id, id));
    return box || undefined;
  }

  async getBoxByBoxId(boxId: string): Promise<Box | undefined> {
    const [box] = await db.select().from(boxes).where(eq(boxes.boxId, boxId));
    return box || undefined;
  }

  async getAllBoxes(): Promise<Box[]> {
    return await db.select().from(boxes).orderBy(desc(boxes.lastUpdated));
  }

  async updateBox(id: number, updates: Partial<Box>): Promise<Box> {
    const [box] = await db
      .update(boxes)
      .set({
        ...updates,
        lastUpdated: new Date(),
      })
      .where(eq(boxes.id, id))
      .returning();

    if (!box) {
      throw new Error('Box not found');
    }

    // Create activity if status changed
    if (updates.status) {
      await this.createBoxActivity({
        boxId: box.boxId,
        action: `Status updated to ${updates.status}`,
        location: updates.currentLocation || box.currentLocation,
      });
    }

    return box;
  }

  async getBoxesByStatus(status: string): Promise<Box[]> {
    return await db.select().from(boxes).where(eq(boxes.status, status));
  }

  async searchBoxes(query: string): Promise<Box[]> {
    const searchTerm = `%${query.toLowerCase()}%`;
    return await db
      .select()
      .from(boxes)
      .where(
        or(
          like(sql`lower(${boxes.boxId})`, searchTerm),
          like(sql`lower(${boxes.status})`, searchTerm),
          like(sql`lower(${boxes.currentLocation})`, searchTerm),
          like(sql`lower(${boxes.type})`, searchTerm)
        )
      );
  }

  async createBoxActivity(insertActivity: InsertBoxActivity): Promise<BoxActivity> {
    const [activity] = await db
      .insert(boxActivities)
      .values({
        ...insertActivity,
        location: insertActivity.location || null,
      })
      .returning();
    return activity;
  }

  async getBoxActivities(boxId: string): Promise<BoxActivity[]> {
    return await db
      .select()
      .from(boxActivities)
      .where(eq(boxActivities.boxId, boxId))
      .orderBy(desc(boxActivities.timestamp));
  }

  async getRecentActivities(limit: number = 10): Promise<BoxActivity[]> {
    return await db
      .select()
      .from(boxActivities)
      .orderBy(desc(boxActivities.timestamp))
      .limit(limit);
  }

  async getBoxStatusCounts(): Promise<Record<string, number>> {
    const result = await db
      .select({
        status: boxes.status,
        count: sql<number>`count(*)::int`,
      })
      .from(boxes)
      .groupBy(boxes.status);

    const counts: Record<string, number> = {};
    result.forEach(row => {
      counts[row.status] = row.count;
    });
    return counts;
  }

  async getBoxMetrics(): Promise<{
    totalBoxes: number;
    inTransit: number;
    delivered: number;
    utilizationRate: number;
  }> {
    const totalResult = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(boxes);
    
    const inTransitResult = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(boxes)
      .where(eq(boxes.status, BoxStatus.IN_TRANSIT));
    
    const deliveredResult = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(boxes)
      .where(eq(boxes.status, BoxStatus.DELIVERED));
    
    const activeResult = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(boxes)
      .where(
        sql`${boxes.status} != ${BoxStatus.NEW} AND ${boxes.status} != ${BoxStatus.MAINTENANCE}`
      );

    const totalBoxes = totalResult[0]?.count || 0;
    const inTransit = inTransitResult[0]?.count || 0;
    const delivered = deliveredResult[0]?.count || 0;
    const activeBoxes = activeResult[0]?.count || 0;
    
    const utilizationRate = totalBoxes > 0 ? Math.round((activeBoxes / totalBoxes) * 100) : 0;

    return {
      totalBoxes,
      inTransit,
      delivered,
      utilizationRate,
    };
  }
}

export const storage = new DatabaseStorage();
