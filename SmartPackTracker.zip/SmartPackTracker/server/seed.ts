import { db } from "./db";
import { boxes, boxActivities } from "@shared/schema";
import { BoxStatus, BoxType } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database with sample data...");

  // Sample boxes data
  const sampleBoxes = [
    {
      boxId: 'SB-001847',
      type: BoxType.STANDARD_MEDIUM,
      status: BoxStatus.DELIVERED,
      currentLocation: 'Warehouse A, Dock 2',
      cycles: 23,
    },
    {
      boxId: 'SB-001523',
      type: BoxType.STANDARD_LARGE,
      status: BoxStatus.IN_TRANSIT,
      currentLocation: 'Highway Route 95',
      cycles: 47,
    },
    {
      boxId: 'SB-002103',
      type: BoxType.STANDARD_SMALL,
      status: BoxStatus.NEW,
      currentLocation: 'Production Facility',
      cycles: 0,
    },
    {
      boxId: 'SB-001298',
      type: BoxType.REFRIGERATED_MEDIUM,
      status: BoxStatus.MAINTENANCE,
      currentLocation: 'Repair Center B',
      cycles: 89,
    },
    {
      boxId: 'SB-001756',
      type: BoxType.STANDARD_MEDIUM,
      status: BoxStatus.RETURNED,
      currentLocation: 'Central Hub',
      cycles: 34,
    },
  ];

  try {
    // Insert boxes
    const insertedBoxes = await db.insert(boxes).values(sampleBoxes).returning();
    console.log(`Inserted ${insertedBoxes.length} boxes`);

    // Insert activities for each box
    const activities = insertedBoxes.map((box) => ({
      boxId: box.boxId,
      action: `Box ${box.status === BoxStatus.NEW ? 'registered as new' : 
                    box.status === BoxStatus.IN_TRANSIT ? 'in transit' :
                    box.status === BoxStatus.DELIVERED ? 'delivered' :
                    box.status === BoxStatus.RETURNED ? 'returned' :
                    'requires maintenance'}`,
      location: box.currentLocation,
    }));

    const insertedActivities = await db.insert(boxActivities).values(activities).returning();
    console.log(`Inserted ${insertedActivities.length} activities`);

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Run if called directly
seedDatabase().then(() => process.exit(0));

export { seedDatabase };