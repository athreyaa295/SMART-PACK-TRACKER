import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBoxSchema, insertBoxActivitySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all boxes
  app.get("/api/boxes", async (req, res) => {
    try {
      const { status, search } = req.query;
      
      let boxes;
      if (search) {
        boxes = await storage.searchBoxes(search as string);
      } else if (status && status !== 'all') {
        boxes = await storage.getBoxesByStatus(status as string);
      } else {
        boxes = await storage.getAllBoxes();
      }
      
      res.json(boxes);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch boxes' });
    }
  });

  // Get box by ID
  app.get("/api/boxes/:id", async (req, res) => {
    try {
      const box = await storage.getBox(parseInt(req.params.id));
      if (!box) {
        return res.status(404).json({ error: 'Box not found' });
      }
      res.json(box);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch box' });
    }
  });

  // Create new box
  app.post("/api/boxes", async (req, res) => {
    try {
      const validatedData = insertBoxSchema.parse(req.body);
      const box = await storage.createBox(validatedData);
      res.status(201).json(box);
    } catch (error) {
      res.status(400).json({ error: 'Invalid box data' });
    }
  });

  // Update box
  app.patch("/api/boxes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const box = await storage.updateBox(id, updates);
      res.json(box);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update box' });
    }
  });

  // Get box activities
  app.get("/api/boxes/:boxId/activities", async (req, res) => {
    try {
      const activities = await storage.getBoxActivities(req.params.boxId);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch activities' });
    }
  });

  // Get recent activities
  app.get("/api/activities/recent", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const activities = await storage.getRecentActivities(limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch recent activities' });
    }
  });

  // Get dashboard metrics
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getBoxMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch metrics' });
    }
  });

  // Get status distribution
  app.get("/api/dashboard/status-distribution", async (req, res) => {
    try {
      const statusCounts = await storage.getBoxStatusCounts();
      res.json(statusCounts);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch status distribution' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
