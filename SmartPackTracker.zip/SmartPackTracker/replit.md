# SmartBox Packaging Management System

## Overview

This is a full-stack web application for managing packaging boxes and tracking their lifecycle. The system provides real-time monitoring of box statuses, location tracking, and analytics for packaging operations. Built with a modern tech stack featuring React frontend, Express backend, and PostgreSQL database with Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management
- **UI Framework**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API architecture
- **Middleware**: Express middleware for logging, JSON parsing, and error handling
- **Development**: Hot reload with Vite integration in development mode

### Database Architecture
- **Database**: PostgreSQL with full persistence
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Connection**: Neon Database serverless for cloud deployment
- **Schema**: Type-safe schema definitions with Zod validation
- **Storage**: DatabaseStorage implementation replacing in-memory storage
- **Seeding**: Automated sample data initialization

## Key Components

### Core Entities
1. **Boxes**: Main packaging units with lifecycle tracking
   - Unique box IDs, types, status, current location
   - Cycle counting for reusability metrics
   - Status tracking (new, in-transit, delivered, returned, maintenance)

2. **Box Activities**: Activity log for box lifecycle events
   - Action tracking, location updates, timestamps
   - Audit trail for compliance and analytics

3. **Box Types**: Standardized packaging options
   - Small (10L), Medium (25L), Large (50L) standard boxes
   - Refrigerated Medium (25L) for temperature-sensitive items

### Frontend Components
- **Dashboard**: Main overview with metrics and charts
- **Box Registration**: Form for adding new boxes to inventory
- **Box Table**: Searchable/filterable list of all boxes
- **Analytics Widgets**: Status distribution, lifecycle charts, activity feeds
- **Mobile Support**: Responsive design with mobile-first approach

### Backend Services
- **Storage Layer**: Abstracted storage interface with PostgreSQL database implementation
- **API Routes**: RESTful endpoints for CRUD operations
- **Validation**: Zod schema validation for request/response data
- **Error Handling**: Centralized error handling with proper HTTP status codes
- **Database Operations**: Type-safe queries with Drizzle ORM

## Data Flow

1. **Box Registration**: Frontend form → API validation → Database storage → Real-time updates
2. **Status Updates**: Activity creation → Box status update → Analytics refresh → UI updates
3. **Search/Filter**: User input → API query with filters → Database search → Results display
4. **Analytics**: Database aggregation → Metrics calculation → Chart rendering → Dashboard display

### Real-time Updates
- React Query for automatic data synchronization
- Optimistic updates for better user experience
- Cache invalidation on mutations

## External Dependencies

### UI/UX Libraries
- Radix UI for accessible, unstyled components
- Lucide React for consistent iconography
- Recharts for data visualization
- Date-fns for date manipulation
- React Hook Form with Hookform Resolvers for form handling

### Development Tools
- ESBuild for production bundling
- PostCSS with Autoprefixer for CSS processing
- Replit-specific plugins for development environment integration

### Database & Validation
- Drizzle ORM for type-safe database operations
- Drizzle Zod for schema-to-Zod validation generation
- Neon Database serverless for PostgreSQL hosting

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend
- Express server with TypeScript compilation via tsx
- Replit-specific development tooling and error overlays

### Production Build
1. Frontend: Vite builds React app to `dist/public`
2. Backend: ESBuild bundles server code to `dist/index.js`
3. Database: Drizzle migrations applied via `db:push` command

### Environment Configuration
- Database URL configuration via environment variables
- Separate development and production build processes
- Static file serving in production mode

### Mobile Considerations
- Progressive Web App capabilities
- Touch-friendly interface design
- Offline-first considerations for field operations
- Responsive breakpoints for tablet and mobile devices

## Technical Decisions

### Database Choice
- **Problem**: Need for reliable, scalable data storage with complex queries
- **Solution**: PostgreSQL with Drizzle ORM and full persistence
- **Rationale**: Strong typing, excellent query capabilities, cloud hosting options, data persistence
- **Implementation**: DatabaseStorage class with optimized queries and proper error handling
- **Alternatives**: MongoDB (rejected due to relational data needs), SQLite (rejected due to scalability)

### State Management
- **Problem**: Complex server state synchronization with optimistic updates
- **Solution**: TanStack React Query
- **Rationale**: Built-in caching, background refetching, optimistic updates
- **Alternatives**: Redux (too complex), native fetch (lacks caching)

### UI Framework
- **Problem**: Need for accessible, customizable components
- **Solution**: Radix UI with shadcn/ui
- **Rationale**: Accessibility-first, headless components, full customization
- **Alternatives**: Material-UI (too opinionated), Chakra UI (less customizable)

### Routing Solution
- **Problem**: Lightweight client-side routing without React Router complexity
- **Solution**: Wouter
- **Rationale**: Minimal bundle size, hook-based API, sufficient for simple routing needs
- **Alternatives**: React Router (too heavy), Reach Router (deprecated)

## Recent Changes

### Database Integration (January 22, 2025)
- **Added**: PostgreSQL database with Drizzle ORM
- **Replaced**: In-memory storage with persistent DatabaseStorage implementation
- **Created**: Database connection layer with proper error handling
- **Implemented**: Sample data seeding for immediate functionality
- **Updated**: All storage operations to use type-safe database queries
- **Benefits**: Data persistence, scalability, production-ready architecture