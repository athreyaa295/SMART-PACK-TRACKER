import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BoxType, BoxStatus } from "@shared/schema";
import { Plus, Search, FileDown, Settings } from "lucide-react";

export default function BoxRegistration() {
  const [type, setType] = useState("");
  const [location, setLocation] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createBoxMutation = useMutation({
    mutationFn: async (data: { type: string; currentLocation: string }) => {
      const response = await apiRequest("POST", "/api/boxes", {
        type: data.type,
        status: BoxStatus.NEW,
        currentLocation: data.currentLocation,
        cycles: 0,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/boxes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/status-distribution"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities/recent"] });
      
      toast({
        title: "Success",
        description: "Box registered successfully",
      });
      
      setType("");
      setLocation("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to register box",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!type || !location) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }
    
    createBoxMutation.mutate({ type, currentLocation: location });
  };

  return (
    <Card className="shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
      </div>
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Register New Box
            </Label>
            <Input 
              placeholder="Box ID (auto-generated)" 
              disabled 
              className="bg-gray-50"
            />
          </div>
          
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Box Type
            </Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue placeholder="Select box type..." />
              </SelectTrigger>
              <SelectContent>
                {Object.values(BoxType).map((boxType) => (
                  <SelectItem key={boxType} value={boxType}>
                    {boxType}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Initial Location
            </Label>
            <Input 
              type="text" 
              placeholder="e.g., Warehouse A, Dock 3" 
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full" 
            disabled={createBoxMutation.isPending}
          >
            <Plus className="w-4 h-4 mr-2" />
            {createBoxMutation.isPending ? "Registering..." : "Register Box"}
          </Button>
        </form>

        <div className="mt-6 pt-6 border-t border-gray-200 space-y-3">
          <Button variant="outline" className="w-full">
            <Search className="w-4 h-4 mr-2" />
            Search Boxes
          </Button>
          <Button variant="outline" className="w-full">
            <FileDown className="w-4 h-4 mr-2" />
            Export Report
          </Button>
          <Button variant="outline" className="w-full">
            <Settings className="w-4 h-4 mr-2" />
            System Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
