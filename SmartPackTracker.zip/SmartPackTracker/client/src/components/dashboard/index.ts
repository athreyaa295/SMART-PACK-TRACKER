// Export all dashboard components
export { default as Sidebar } from './sidebar';
export { default as StatsOverview } from './stats-overview';
export { default as LifecycleChart } from './lifecycle-chart';
export { default as StatusDistribution } from './status-distribution';
export { default as RecentActivity } from './recent-activity';
export { default as BoxRegistration } from './box-registration';
export { default as BoxTable } from './box-table';
export { default as MobileBottomNav } from './mobile-bottom-nav';
export { default as MobileHeader } from './mobile-header';