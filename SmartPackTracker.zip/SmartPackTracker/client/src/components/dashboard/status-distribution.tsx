import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

export default function StatusDistribution() {
  const { data: statusCounts, isLoading } = useQuery({
    queryKey: ["/api/dashboard/status-distribution"],
  });

  if (isLoading) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Status Distribution</h3>
        </div>
        <CardContent className="p-6">
          <div className="h-[300px] bg-gray-100 rounded animate-pulse"></div>
        </CardContent>
      </Card>
    );
  }

  const chartData = Object.entries(statusCounts || {}).map(([status, count]) => ({
    name: status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' '),
    value: count,
  }));

  const COLORS = {
    'In transit': 'hsl(25, 95%, 53%)',
    'Delivered': 'hsl(142, 76%, 36%)',
    'New': 'hsl(207, 90%, 54%)',
    'Returned': 'hsl(220, 9%, 46%)',
    'Maintenance': 'hsl(0, 84%, 60%)',
  };

  return (
    <Card className="shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Status Distribution</h3>
      </div>
      <CardContent className="p-6">
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={5}
              dataKey="value"
            >
              {chartData.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[entry.name as keyof typeof COLORS] || '#8884d8'} 
                />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
