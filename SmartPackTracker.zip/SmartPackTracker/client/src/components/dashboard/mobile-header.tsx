import { Menu, Bell } from "lucide-react";

interface MobileHeaderProps {
  onMenuToggle: () => void;
}

export default function MobileHeader({ onMenuToggle }: MobileHeaderProps) {
  return (
    <div className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
      <button onClick={onMenuToggle} className="text-gray-600 hover:text-gray-900">
        <Menu className="w-6 h-6" />
      </button>
      <div className="flex items-center space-x-2">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
          <div className="w-4 h-4 bg-white rounded"></div>
        </div>
        <span className="font-semibold text-gray-900">SmartBox</span>
      </div>
      <div className="flex items-center space-x-3">
        <button className="text-gray-600 hover:text-gray-900">
          <Bell className="w-5 h-5" />
        </button>
        <div className="w-8 h-8 bg-gray-300 rounded-full"></div>
      </div>
    </div>
  );
}
