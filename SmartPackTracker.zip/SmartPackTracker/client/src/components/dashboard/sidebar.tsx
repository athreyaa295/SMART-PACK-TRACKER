import { cn } from "@/lib/utils";
import { 
  BarChart3, 
  Package, 
  Route, 
  MapPin, 
  TrendingUp, 
  FileText, 
  Settings 
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const menuItems = [
    { icon: BarChart3, label: "Dashboard", active: true },
    { icon: Package, label: "Box Inventory", active: false },
    { icon: Route, label: "Lifecycle Tracking", active: false },
    { icon: MapPin, label: "Location Tracking", active: false },
    { icon: TrendingUp, label: "Analytics", active: false },
    { icon: FileText, label: "Reports", active: false },
    { icon: Settings, label: "Settings", active: false },
  ];

  return (
    <aside 
      className={cn(
        "fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out",
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}
    >
      <div className="flex items-center space-x-3 p-6 border-b border-gray-200">
        <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
          <div className="w-5 h-5 bg-white rounded"></div>
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-900">SmartBox</h1>
          <p className="text-sm text-gray-500">Packaging Management</p>
        </div>
      </div>

      <nav className="p-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <a
              key={item.label}
              href="#"
              className={cn(
                "flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors",
                item.active
                  ? "bg-primary/10 text-primary border border-primary/20"
                  : "text-gray-600 hover:bg-gray-50"
              )}
            >
              <Icon className="w-5 h-5" />
              <span className={cn("font-medium", item.active && "font-semibold")}>{item.label}</span>
            </a>
          );
        })}
      </nav>
    </aside>
  );
}
