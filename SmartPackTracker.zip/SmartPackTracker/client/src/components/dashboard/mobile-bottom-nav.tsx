import { BarChart3, Package, Route, TrendingUp, User } from "lucide-react";

export default function MobileBottomNav() {
  const navItems = [
    { icon: BarChart3, label: "Dashboard", active: true },
    { icon: Package, label: "Boxes", active: false },
    { icon: Route, label: "Tracking", active: false },
    { icon: TrendingUp, label: "Analytics", active: false },
    { icon: User, label: "Profile", active: false },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200">
      <div className="grid grid-cols-5 py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              className={`flex flex-col items-center py-2 px-1 ${
                item.active ? "text-primary" : "text-gray-600"
              }`}
            >
              <Icon className="w-5 h-5 mb-1" />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
