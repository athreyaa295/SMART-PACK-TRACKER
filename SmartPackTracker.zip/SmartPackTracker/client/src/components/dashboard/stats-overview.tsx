import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Package, Truck, CheckCircle, PieChart } from "lucide-react";

export default function StatsOverview() {
  const { data: metrics, isLoading } = useQuery<{
    totalBoxes: number;
    inTransit: number;
    delivered: number;
    utilizationRate: number;
  }>({
    queryKey: ["/api/dashboard/metrics"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-16 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const stats = [
    {
      title: "Total Boxes",
      value: metrics?.totalBoxes || 0,
      change: "+12%",
      changeLabel: "from last month",
      icon: Package,
      iconBg: "bg-primary/10",
      iconColor: "text-primary",
      changeColor: "text-green-600",
    },
    {
      title: "In Transit",
      value: metrics?.inTransit || 0,
      change: "+5%",
      changeLabel: "from yesterday",
      icon: Truck,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      changeColor: "text-orange-600",
    },
    {
      title: "Delivered",
      value: metrics?.delivered || 0,
      change: "+8%",
      changeLabel: "completion rate",
      icon: CheckCircle,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      changeColor: "text-green-600",
    },
    {
      title: "Utilization Rate",
      value: `${metrics?.utilizationRate || 0}%`,
      change: "+3%",
      changeLabel: "efficiency gain",
      icon: PieChart,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      changeColor: "text-green-600",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.title} className="shadow-sm border border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 ${stat.iconBg} rounded-lg flex items-center justify-center`}>
                  <Icon className={`${stat.iconColor} w-6 h-6`} />
                </div>
              </div>
              <div className="flex items-center mt-4">
                <span className={`${stat.changeColor} text-sm font-medium`}>{stat.change}</span>
                <span className="text-gray-500 text-sm ml-2">{stat.changeLabel}</span>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
