import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";

export default function RecentActivity() {
  const { data: activities, isLoading } = useQuery<any[]>({
    queryKey: ["/api/activities/recent"],
  });

  if (isLoading) {
    return (
      <Card className="shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
        </div>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-start space-x-4 animate-pulse">
                <div className="w-2 h-2 bg-gray-300 rounded-full mt-2"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-300 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-20"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusColor = (action: string) => {
    if (action.includes('delivered')) return 'bg-green-500';
    if (action.includes('transit')) return 'bg-orange-500';
    if (action.includes('new')) return 'bg-blue-500';
    if (action.includes('maintenance')) return 'bg-red-500';
    if (action.includes('returned')) return 'bg-gray-500';
    return 'bg-gray-400';
  };

  return (
    <Card className="shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
          <button className="text-primary hover:text-primary/80 text-sm font-medium">
            View All
          </button>
        </div>
      </div>
      <CardContent className="p-6">
        <div className="space-y-4">
          {activities?.slice(0, 5).map((activity) => (
            <div key={activity.id} className="flex items-start space-x-4">
              <div className={`w-2 h-2 ${getStatusColor(activity.action)} rounded-full mt-2`}></div>
              <div className="flex-1">
                <p className="text-sm text-gray-900">
                  Box <span className="font-medium">{activity.boxId}</span> {activity.action.toLowerCase()}
                </p>
                <p className="text-xs text-gray-500">
                  {formatDistanceToNow(new Date(activity.timestamp!), { addSuffix: true })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
