import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function LifecycleChart() {
  // Mock data for the chart - in a real app, this would come from an API
  const chartData = [
    { period: "Week 1", new: 120, delivered: 80, returned: 60 },
    { period: "Week 2", new: 140, delivered: 95, returned: 70 },
    { period: "Week 3", new: 160, delivered: 110, returned: 85 },
    { period: "Week 4", new: 180, delivered: 125, returned: 95 },
  ];

  return (
    <Card className="shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Box Lifecycle Overview</h3>
          <Select defaultValue="30">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <CardContent className="p-6">
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="period" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="new" 
              stroke="hsl(207, 90%, 54%)" 
              strokeWidth={2}
              name="New Registrations"
            />
            <Line 
              type="monotone" 
              dataKey="delivered" 
              stroke="hsl(142, 76%, 36%)" 
              strokeWidth={2}
              name="Delivered"
            />
            <Line 
              type="monotone" 
              dataKey="returned" 
              stroke="hsl(25, 95%, 53%)" 
              strokeWidth={2}
              name="Returned"
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
