import { useIsMobile } from "@/hooks/use-mobile";
import {
  MobileHeader,
  Sidebar,
  StatsOverview,
  LifecycleChart,
  StatusDistribution,
  RecentActivity,
  BoxRegistration,
  BoxTable,
  MobileBottomNav
} from "@/components/dashboard";
import { useState } from "react";
import { Search, Bell } from "lucide-react";

export default function Dashboard() {
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="bg-gray-50 min-h-screen">
      {isMobile && <MobileHeader onMenuToggle={() => setSidebarOpen(!sidebarOpen)} />}
      
      <div className="flex min-h-screen">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        
        {/* Overlay for mobile sidebar */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 overflow-x-hidden">
          {/* Desktop Header */}
          {!isMobile && (
            <header className="flex items-center justify-between px-6 py-4 bg-white border-b border-gray-200">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
                <p className="text-gray-600">Welcome back! Here's your packaging overview.</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Search boxes..." 
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                </div>
                <button className="p-2 text-gray-600 hover:text-gray-900 relative">
                  <Bell className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
                </button>
                <div className="flex items-center space-x-3">
                  <div className="text-right">
                    <p className="font-medium text-gray-900">John Smith</p>
                    <p className="text-sm text-gray-500">Logistics Manager</p>
                  </div>
                  <div className="w-10 h-10 bg-gray-300 rounded-full"></div>
                </div>
              </div>
            </header>
          )}

          <div className="p-6">
            <StatsOverview />

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-8">
              <div className="xl:col-span-2">
                <LifecycleChart />
              </div>
              <StatusDistribution />
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
              <RecentActivity />
              <BoxRegistration />
            </div>

            <BoxTable />
          </div>
        </main>
      </div>

      {isMobile && <MobileBottomNav />}
    </div>
  );
}
