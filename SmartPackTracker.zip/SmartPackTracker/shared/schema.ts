import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const boxes = pgTable("boxes", {
  id: serial("id").primaryKey(),
  boxId: text("box_id").notNull().unique(),
  type: text("type").notNull(),
  status: text("status").notNull(),
  currentLocation: text("current_location").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow(),
  cycles: integer("cycles").default(0),
});

export const boxActivities = pgTable("box_activities", {
  id: serial("id").primaryKey(),
  boxId: text("box_id").notNull(),
  action: text("action").notNull(),
  location: text("location"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertBoxSchema = createInsertSchema(boxes).omit({
  id: true,
  lastUpdated: true,
});

export const insertBoxActivitySchema = createInsertSchema(boxActivities).omit({
  id: true,
  timestamp: true,
});

export type InsertBox = z.infer<typeof insertBoxSchema>;
export type Box = typeof boxes.$inferSelect;
export type InsertBoxActivity = z.infer<typeof insertBoxActivitySchema>;
export type BoxActivity = typeof boxActivities.$inferSelect;

export const BoxStatus = {
  NEW: 'new',
  IN_TRANSIT: 'in-transit',
  DELIVERED: 'delivered',
  RETURNED: 'returned',
  MAINTENANCE: 'maintenance',
} as const;

export const BoxType = {
  STANDARD_SMALL: 'Standard - Small (10L)',
  STANDARD_MEDIUM: 'Standard - Medium (25L)',
  STANDARD_LARGE: 'Standard - Large (50L)',
  REFRIGERATED_MEDIUM: 'Refrigerated - Medium (25L)',
  REFRIGERATED_LARGE: 'Refrigerated - Large (50L)',
} as const;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});
